
public class Block {
	public static void main(String[] args) {
		Grid g = new Grid(5);
		
		Block b = new Block();
		b.drawOn(g, 0, 0);
		
		g.print();
		System.out.println("-------------");
		g.update();
		g.print();
	}

	public void drawOn(Grid g, int i, int j)
	{
		g.resurrect(i, j);
		g.resurrect(i+1, j);
		g.resurrect(i, j+1);
		g.resurrect(i+1, j+1);
	}
}
