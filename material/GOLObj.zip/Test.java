import java.util.Random;

public class Test {
	public static void main(String[] args) throws InterruptedException {
		int n = 20;

		Grid grid = new Grid(n);
		
		Random r = new Random(42);
		
		for(int i = 0; i < 5; ++i) {
			Blinker b = new Blinker();
			b.drawOn(grid, r.nextInt(n), r.nextInt(n));
		}
		// grid[0][0] = true;
		// grid[1][0] = true;
		// grid[0][1] = true;
		// grid[1][1] = true;

		while(true)
		{
			grid.print();
			grid.update();
			Thread.sleep(200);

//			System.out.print("\033[H\033[2J");
  			System.out.flush();
		}
		
	}
}
