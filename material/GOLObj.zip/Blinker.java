
public class Blinker {
	public static void main(String[] args) {
		Grid g = new Grid(5);
		
		Blinker b = new Blinker();
		b.drawOn(g, 0, 1);
		
		g.print();
		System.out.println("-------------");
		g.update();
		g.print();
	}

	public void drawOn(Grid g, int i, int j)
	{
		g.resurrect(i, j);
		g.resurrect(i+1, j);
		g.resurrect(i+2, j);
	}
}
