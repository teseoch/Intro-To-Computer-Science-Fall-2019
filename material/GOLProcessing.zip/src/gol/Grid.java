package gol;


public class Grid {
	public static void main(String[] args) {
		Grid g = new Grid(4, 0.8);
		g.print();
	}
	
	private int size;
	private boolean[][] alive;
	
	public Grid(int size)
	{
		this.size = size;
		alive = new boolean[size][size];
	}
	
	public Grid(int size, double alive_perc)
	{
		this(size);
		
		setRandom(alive_perc);
	}
	
	public void setRandom(double alive_perc)
	{
		for (int i = 0; i < size ; ++i ) {
			for (int j = 0; j < size; j++) {
				alive[i][j] = Math.random() < alive_perc;
			}
		}
	}
	
	public void print()
	{
//		final char ALIVE = '\u2B1B';
//		final String DEAD = "  ";
		final char ALIVE = 'x';
		final String DEAD = " ";

		for (int i = 0; i < size ; ++i ) {
			for (int j = 0; j < size; j++) {
				if(alive[i][j])
					System.out.print(ALIVE);
				else
					System.out.print(DEAD);
			}
			System.out.println();
		}
	}

	
	public void update()
	{
		int n = size;
		boolean[][] newGrid = new boolean[n][n];

		for (int i = 0; i < n ; ++i ) {
			for (int j = 0; j < n; j++) {
				int nAlive = countAliveN(i, j);

				if(alive[i][j])
				{
					if(nAlive < 2)
						newGrid[i][j] = false;
					if(nAlive == 2 || nAlive == 3)
						newGrid[i][j] = true;
					else //nAlive > 3
						newGrid[i][j] = false;
				}
				else
				{
					if(nAlive == 3)
						newGrid[i][j] = true;
					else
						newGrid[i][j] = false;
				}
			}
		}

		for (int i = 0; i < n ; ++i ) {
			for (int j = 0; j < n; j++) {
				alive[i][j] = newGrid[i][j];
			}
		}
	}
	
	public boolean getAlive(int i, int j)
	{
		//i > -n
		int tmpi = (i+size)%size;
		int tmpj = (j+size)%size;

		return alive[tmpi][tmpj];
	}
	
	private int countAliveN(int i, int j)
	{
		int count = 0;

		for(int x = i - 1; x <= i + 1; ++x)
		{
			for(int y = j - 1; y <= j + 1; ++y)
			{
				if(x == i && y == j)
					continue;

				if(getAlive(x, y))
					++count;
			}
		}

		return count;
	}
	
	public int getSize() {
		return size;
	}

	
	public boolean[][] getAlive() {
		return alive;
	}

	
	public void setSize(int size) {
		this.size = size;
		this.alive = new boolean[size][size];
	}
	
	public void resurrect(int i, int j)
	{
		int tmpi = (i+size)%size;
		int tmpj = (j+size)%size;

		alive[tmpi][tmpj] = true;
	}
	
	public void kill(int i, int j)
	{
		int tmpi = (i+size)%size;
		int tmpj = (j+size)%size;

		alive[tmpi][tmpj] = false;
	}
	
	//setters...
}
