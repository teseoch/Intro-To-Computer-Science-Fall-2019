package pkg;

import processing.core.PApplet;

public class Test extends PApplet {
	public static void main(String[] args) {
		PApplet.main("pkg.Test");
	}
	
	
	public void settings() {
		size(500, 500);
	}
	
	
	public void draw(){
		ellipse(mouseX,mouseY,10,10);
	}
}