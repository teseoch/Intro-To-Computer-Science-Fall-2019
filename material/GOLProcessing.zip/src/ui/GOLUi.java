package ui;

import gol.Grid;
import processing.core.PApplet;

public class GOLUi extends PApplet {
	public static void main(String[] args) {
		PApplet.main("ui.GOLUi");
	}

	static final int GRID_SIZE = 500;
	static final int CELL_SIZE = 5;

	private Grid grid;
	private int counter;
	private boolean isPause;

	public void setup()
	{
		grid = new Grid(GRID_SIZE, 0.1);

		counter = 0;
		isPause = false;
	}

	public void settings() {
		size(GRID_SIZE*CELL_SIZE, GRID_SIZE*CELL_SIZE);
	}

	public void keyPressed() {
		boolean isSpace = key == ' ';
		
		if(isSpace)
			isPause = !isPause;
	}


	public void draw(){
		++counter;
		fill(255, 255, 255);
		rect(-1, -1,GRID_SIZE*CELL_SIZE+2, GRID_SIZE*CELL_SIZE+2);

		fill(192, 0, 240);
//		stroke(192, 0, 240);

		if (mousePressed) {
			int i = mouseX/CELL_SIZE;
			int j = mouseY/CELL_SIZE;
			
			 if(mouseButton == LEFT)
				 grid.resurrect(i, j);
			 else
				 grid.kill(i, j);
		}


		for (int i = 0; i < grid.getSize(); ++i ) {
			for (int j = 0; j < grid.getSize(); j++) {
				if(grid.getAlive(i, j)) {
					rect(i*CELL_SIZE, j*CELL_SIZE,
							CELL_SIZE, CELL_SIZE);
				}
			}
		}

		if(counter > 10) {
			if(!isPause)
				grid.update();
			counter=0;
		}
	}
}